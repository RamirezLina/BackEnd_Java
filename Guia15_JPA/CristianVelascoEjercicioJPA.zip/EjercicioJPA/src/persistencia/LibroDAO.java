package persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;

public class LibroDAO extends DAO<Libro> {

    @Override
    public void persistirEntidad(Libro object) {
        super.persistirEntidad(object);
    }

    @Override
    public void actualizarEntidad(Libro object) {
        super.actualizarEntidad(object);
    }

    @Override
    public void eliminarEntidad(Libro object) {
        super.eliminarEntidad(object);
    }
    
    public Libro buscarLibroPorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            return em.find(Libro.class, id);
        } catch (PersistenceException e) {
            System.out.println("Error al buscar el libro por ID.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Libro> buscarLibros() {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Libro> consulta = em.createQuery("SELECT u FROM Libro u", Libro.class);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar todos los libros.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Libro> buscarLibrosPorAutor(Autor autor) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Libro> consulta = em.createQuery("SELECT u FROM Libro u WHERE u.autor = :autor", Libro.class);
            consulta.setParameter("autor", autor);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar libros por autor.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Libro> buscarLibrosPorEditorial(Editorial editorial) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Libro> consulta = em.createQuery("SELECT u FROM Libro u WHERE u.editorial = :editorial", Libro.class);
            consulta.setParameter("editorial", editorial);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar libros por editorial.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public void eliminarPermanentePorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            Libro libro = em.find(Libro.class, id);
            if (libro != null) {
                em.remove(libro);
                em.getTransaction().commit();
            } else {
                System.out.println("No se encontró un libro con el ID proporcionado.");
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar el libro: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Libro> buscarLibrosPorTitulo(String titulo) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Libro> consulta = em.createQuery("SELECT u FROM Libro u WHERE u.titulo LIKE :titulo", Libro.class);
            consulta.setParameter("titulo", "%" + titulo + "%");
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar libros por título.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
}
