package persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import libreria.entidades.Cliente;

public class ClienteDAO extends DAO<Cliente> {
    
    @Override
    public void persistirEntidad(Cliente object) {
        super.persistirEntidad(object);
    }

    @Override
    public void actualizarEntidad(Cliente object) {
        super.actualizarEntidad(object);
    }

    @Override
    public void eliminarEntidad(Cliente object) {
        super.eliminarEntidad(object);
    }
    
    public void eliminarPorDocumento(Long documento) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            TypedQuery<Cliente> query = em.createQuery("SELECT c FROM Cliente c WHERE c.documento = :documento", Cliente.class);
            query.setParameter("documento", documento);

            List<Cliente> clientes = query.getResultList();

            if (!clientes.isEmpty()) {
                Cliente cliente = clientes.get(0);
                em.remove(cliente);
                em.getTransaction().commit();
                System.out.println("El cliente ha sido eliminado permanentemente.");
            } else {
                System.out.println("No se encontró un cliente con el número de documento proporcionado: " + documento);
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar el cliente: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Cliente> listarClientes() {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Cliente> query = em.createQuery("SELECT u FROM Cliente u", Cliente.class);
            return query.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al listar los clientes.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public Cliente buscarClientePorDocumento(Long documento) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Cliente> query = em.createQuery("SELECT u FROM Cliente u WHERE u.documento = :documento", Cliente.class);
            query.setParameter("documento", documento);
            return query.getSingleResult();
        } catch (PersistenceException e) {
            System.out.println("No se encontró un cliente con el número de documento proporcionado: " + documento);
            return null;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public boolean documentoRepetido(Long documento) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery("SELECT COUNT(u) FROM Cliente u WHERE u.documento = :documento", Long.class);
            query.setParameter("documento", documento);
            Long count = query.getSingleResult();
            return count > 0;
        } catch (PersistenceException e) {
            System.out.println("Error al verificar si el número de documento está repetido.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
}
