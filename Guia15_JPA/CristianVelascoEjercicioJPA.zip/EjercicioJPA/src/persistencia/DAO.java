package persistencia;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

public abstract class DAO<T> {
    private final EntityManagerFactory emf;

    protected DAO() {
        emf = Persistence.createEntityManagerFactory("EjercicioJPAPU");
    }

    protected EntityManager obtenerEntityManager() {
        return emf.createEntityManager();
    }

    protected void cerrarEntityManager(EntityManager em) {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }

    protected void persistirEntidad(T object) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(object);
            em.getTransaction().commit();
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al persistir la entidad: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }

    protected void actualizarEntidad(T object) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(object);
            em.getTransaction().commit();
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al actualizar la entidad: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }

    protected void eliminarEntidad(T object) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            em.remove(object);
            em.getTransaction().commit();
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar la entidad: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
    
}
