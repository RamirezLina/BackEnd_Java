package persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import libreria.entidades.Autor;

public class AutorDAO extends DAO<Autor> {

    @Override
    public void persistirEntidad(Autor object) {
        super.persistirEntidad(object);
    }

    @Override
    public void actualizarEntidad(Autor object) {
        super.actualizarEntidad(object);
    }

    @Override
    public void eliminarEntidad(Autor object) {
        super.eliminarEntidad(object);
    }
    
    public Autor buscarAutorPorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            return em.find(Autor.class, id);
        }catch (PersistenceException e) {
            System.out.println("Error al buscar el autor por ID.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Autor> buscarAutores() {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Autor> consulta = em.createQuery("SELECT u FROM Autor u", Autor.class);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar todos los autores.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public void eliminarPorID(Long id) {
        EntityManager em = obtenerEntityManager();

        try {
            em.getTransaction().begin();

            Autor autor = em.find(Autor.class, id);
            if (autor != null) {
                super.eliminarEntidad(autor);
                em.getTransaction().commit();
                System.out.println("El autor ha sido eliminado exitosamente.");
            } else {
                System.out.println("No se encontró un autor con el ID proporcionado.");
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar el autor: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public void eliminarPermanentePorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            Autor autor = em.find(Autor.class, id);
            if (autor != null) {
                em.remove(autor);
                em.getTransaction().commit();
            } else {
                System.out.println("No se encontró un autor con el ID proporcionado.");
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar el autor: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }

}
