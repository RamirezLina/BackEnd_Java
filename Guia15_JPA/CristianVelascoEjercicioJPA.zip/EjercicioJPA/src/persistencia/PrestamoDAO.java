package persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import libreria.entidades.Prestamo;


public class PrestamoDAO extends DAO<Prestamo> {
    
    @Override
    public void persistirEntidad(Prestamo object) {
        super.persistirEntidad(object);
    }

    @Override
    public void actualizarEntidad(Prestamo object) {
        super.actualizarEntidad(object);
    }

    @Override
    public void eliminarEntidad(Prestamo object) {
        super.eliminarEntidad(object);
    }
    
    public Prestamo buscarPrestamoPorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            return em.find(Prestamo.class, id);
        } catch (PersistenceException e) {
            System.out.println("Error al buscar el préstamo por ID.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Prestamo> buscarPrestamos() {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Prestamo> consulta = em.createQuery("SELECT p FROM Prestamo p", Prestamo.class);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar todos los préstamos.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public void eliminarPermanentePorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            Prestamo prestamo = em.find(Prestamo.class, id);
            if (prestamo != null) {
                em.remove(prestamo);
                em.getTransaction().commit();
            } else {
                System.out.println("No se encontró un préstamo con el ID proporcionado.");
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar el préstamo: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
}
