package persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import libreria.entidades.Editorial;

public class EditorialDAO extends DAO<Editorial> {
    
    @Override
    public void persistirEntidad(Editorial object) {
        super.persistirEntidad(object);
    }

    @Override
    public void actualizarEntidad(Editorial object) {
        super.actualizarEntidad(object);
    }

    @Override
    public void eliminarEntidad(Editorial object) {
        super.eliminarEntidad(object);
    }
    
    public Editorial buscarEditorialPorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            return em.find(Editorial.class, id);
        } catch (PersistenceException e) {
            System.out.println("Error al buscar la editorial por ID.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Editorial> buscarEditoriales() {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Editorial> consulta = em.createQuery("SELECT u FROM Editorial u", Editorial.class);
            return consulta.getResultList();
        } catch (PersistenceException e) {
            System.out.println("Error al buscar todos las editoriales.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public void eliminarPermanentePorID(Long id) {
        EntityManager em = obtenerEntityManager();
        try {
            em.getTransaction().begin();
            Editorial autor = em.find(Editorial.class, id);
            if (autor != null) {
                em.remove(autor);
                em.getTransaction().commit();
            } else {
                System.out.println("No se encontró una editorial con el ID proporcionado.");
            }
        } catch (PersistenceException e) {
            em.getTransaction().rollback();
            System.out.println("Error al eliminar la editorial: " + e.getMessage());
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public Editorial buscarEditorialPorNombre(String nombre) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Editorial> consulta = em.createQuery("SELECT u FROM Editorial u WHERE u.nombre = :nombre", Editorial.class);
            consulta.setParameter("nombre", nombre);
            if(consulta.getSingleResult() != null){
                System.out.println("Se unio la editorial al libro");
            }
            return consulta.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (PersistenceException e) {
            System.out.println("Error al buscar la editorial por nombre.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
    
    public List<Editorial> buscarEditorialPorNombreLista(String nombre) {
        EntityManager em = obtenerEntityManager();
        try {
            TypedQuery<Editorial> consulta = em.createQuery("SELECT u FROM Editorial u WHERE u.nombre LIKE :nombre", Editorial.class);
            consulta.setParameter("nombre", "%" + nombre + "%");
            List<Editorial> editoriales = consulta.getResultList();

            return editoriales;
        } catch (PersistenceException e) {
            System.out.println("Error al buscar la editorial por nombre.");
            throw e;
        } finally {
            cerrarEntityManager(em);
        }
    }
}
