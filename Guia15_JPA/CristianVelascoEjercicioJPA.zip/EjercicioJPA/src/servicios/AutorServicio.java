package servicios;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import javax.persistence.PersistenceException;
import libreria.entidades.Autor;
import libreria.entidades.Libro;
import persistencia.AutorDAO;
import persistencia.LibroDAO;

public class AutorServicio {
    private final Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    private final AutorDAO autorDAO = new AutorDAO();
    private final LibroDAO libroDAO = new LibroDAO();
    
    public Autor crearAutor() {
        Autor autor = new Autor();

        try {
            System.out.print("Ingrese el nombre del autor: ");
            String nombre = leer.next();

            if (nombre.isEmpty()) {
                throw new InputMismatchException("El nombre del autor no puede estar vacío.");
            }

            if (!nombre.matches("^[a-zA-Z\\s]*$")) {
                throw new InputMismatchException("El nombre del autor no puede contener números ni caracteres especiales.");
            }

            autor.setNombre(nombre);
            autor.setAlta(true);
            
            autorDAO.persistirEntidad(autor);

            System.out.println("El autor se ha creado exitosamente.");
        } catch (InputMismatchException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return autor;
    }
    
    public void eliminarAutorPorID() {
        try {
            Long idAutor = obtenerIDParaEliminar();
            if (idAutor != null) {
                Autor autor = autorDAO.buscarAutorPorID(idAutor);

                if (autor != null) {

                    if (autor.getAlta()) {
                        autor.setAlta(false);
                        autorDAO.actualizarEntidad(autor);
                        System.out.println("El autor ha sido eliminado exitosamente.");
                    } else {
                        autor.setAlta(true);
                        autorDAO.actualizarEntidad(autor);
                        System.out.println("El autor ha sido restaurado exitosamente.");
                    }
                    
                } else {
                    System.out.println("No se encontró un autor con el ID proporcionado.");
                }
            } else {
                System.out.println("ID no válido. Ingrese un ID numérico válido.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }

    private Long obtenerIDParaEliminar() {
        System.out.print("Ingrese el ID del autor que desea eliminar: ");
        try {
            Long idAutor = leer.nextLong();
            return idAutor;
        } catch (InputMismatchException e) {
            return null;
        }
    }
    
    public void mostrarAutores() {
        List<Autor> autores = autorDAO.buscarAutores();

        if (autores.isEmpty()) {
            System.out.println("No hay autores registrados en la base de datos.");
        } else {
            System.out.println("Lista de Autores:");
            for (Autor autor : autores) {
                System.out.println(autor);
            }
        }
    }
    
    public void eliminarAutorPermanentePorID() {
        try {
            System.out.print("Ingrese el ID del autor que desea eliminar permanentemente: ");
            Long idAutor = leer.nextLong();

            Autor autor = autorDAO.buscarAutorPorID(idAutor);

            if (autor != null) {
                if (tieneLibrosAsociados(autor)) {
                    System.out.println("No se puede eliminar este autor directamente, ya que tiene libros asociados.");
                    System.out.println("Primero elimine los libros relacionados con este autor.");
                } else {
                    autorDAO.eliminarPermanentePorID(idAutor);
                    System.out.println("El autor ha sido eliminado permanentemente.");
                }
            } else {
                System.out.println("No se encontró un autor con el ID proporcionado.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }
    
    private boolean tieneLibrosAsociados(Autor autor) {
        List<Libro> librosDelAutor = libroDAO.buscarLibrosPorAutor(autor);

        return !librosDelAutor.isEmpty();
    }

    public Autor buscarAutorPorNombre(String nombre) {
        try {
            List<Autor> autores = autorDAO.buscarAutores();

            for (Autor autor : autores) {
                if (autor.getNombre().equalsIgnoreCase(nombre)) {
                    System.out.println(autor);
                    return autor;
                }
            }

            return null;
        } catch (PersistenceException e) {
            System.out.println("Error al buscar el autor por nombre: " + e.getMessage());
            throw e;
        }
    }
    
}
