package servicios;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import persistencia.LibroDAO;

public class LibroServicio {
    private final Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    private final LibroDAO libroDAO = new LibroDAO();
    private final AutorServicio autorServicio = new AutorServicio();
    private final EditorialServicio editorialServicio = new EditorialServicio();
    
    public Libro crearLibro() {
        Editorial editorial = null;
        Libro libro = new Libro();

        try {
            Long isbn = buscarLibroPorISBN();

            if (isbnRepetido(isbn)) {
                System.out.println("Error: Ya existe un libro con el mismo ISBN.");
                return null;
            }

            libro.setIsbn(isbn);

            System.out.print("Ingrese el título: ");
            String titulo = leer.next();

            if (titulo.isEmpty()) {
                throw new InputMismatchException("El título del libro no puede estar vacío.");
            }
            libro.setTitulo(titulo);

            System.out.print("Ingrese el año: ");
            Integer anio = leer.nextInt();

            if (anio < 0) {
                throw new InputMismatchException("El año debe ser un número positivo.");
            }
            libro.setAnio(anio);

            System.out.print("Ingrese la cantidad de ejemplares: ");
            Integer ejemplares = leer.nextInt();
            if (ejemplares < 0) {
                throw new InputMismatchException("Ejemplar debe ser un número positivo.");
            }
            libro.setEjemplares(ejemplares);

            libro.setEjemplaresPrestados(0);
            libro.setEjemplaresRestantes(ejemplares);
            libro.setAlta(true);

            try {
                Autor autor = buscarAutorPorNombre();
                if (autor == null) {
                    System.out.println("El autor no existe en la base de datos. Creando un nuevo autor...");
                    autor = autorServicio.crearAutor();
                }
                libro.setAutor(autor);
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un nombre válido para el autor.");
                return null;
            }

            System.out.print("Ingrese el nombre de la editorial: ");
            String nombreEditorial = leer.next();

            editorial = editorialServicio.buscarEditorialPorNombre(nombreEditorial);

            if (editorial == null) {
                System.out.println("La editorial no existe en la base de datos. Creando una nueva editorial...");
                editorial = editorialServicio.crearEditorial();
            }

            libro.setEditorial(editorial);

            libroDAO.persistirEntidad(libro);

            System.out.println("El libro se ha creado exitosamente.");
        } catch (InputMismatchException e) {
            System.out.println("Error: " + e.getMessage());
            leer.nextLine();
            return null;
        }

        return libro;
    }

    
    public void eliminarLibroPorID() {
        try {
            Long idLibro = obtenerIDParaEliminar();
            if (idLibro != null) {
                Libro libro = libroDAO.buscarLibroPorID(idLibro);
                
                if (libro != null) {

                    if (libro.getAlta()) {
                        libro.setAlta(false);
                        libroDAO.actualizarEntidad(libro);
                        System.out.println("El libro ha sido eliminado exitosamente.");
                    } else {
                        libro.setAlta(true);
                        libroDAO.actualizarEntidad(libro);
                        System.out.println("El libro ha sido restaurado exitosamente.");
                    }
                } else {
                    System.out.println("No se encontró un libro con el ISBN proporcionado.");
                }
            } else {
                System.out.println("ID no válido. Ingrese un ISBN numérico válido.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }

    private Long obtenerIDParaEliminar() {
        System.out.print("Ingrese el ISBN del libro que desea eliminar: ");
        try {
            Long idLibro = leer.nextLong();
            return idLibro;
        } catch (InputMismatchException e) {
            return null;
        }
    }
    
    public void mostrarLibros() {
        List<Libro> libros = libroDAO.buscarLibros();

        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados en la base de datos.");
        } else {
            System.out.println("Lista de Libros:");
            for (Libro libro : libros) {
                System.out.println(libro);
            }
        }
    }
    
    public void mostrarLibroPorID(Long idLibro) {
        Libro libro = libroDAO.buscarLibroPorID(idLibro);

        if (libro != null) {
            System.out.println("Información del Libro:");
            System.out.println(libro);
        } else {
            System.out.println("No se encontró un libro con el ID proporcionado.");
        }
    }
    
    public void eliminarLibroPermanentePorID() {
        try {
            System.out.print("Ingrese el ISBN del libro que desea eliminar permanentemente: ");
            Long ISBN = leer.nextLong();

            Libro libro = libroDAO.buscarLibroPorID(ISBN);

            if (libro != null) {

                libroDAO.eliminarPermanentePorID(ISBN);
                System.out.println("El libro ha sido eliminado permanentemente.");

            } else {
                System.out.println("No se encontró un libro con el ID proporcionado.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }
    
    public Autor buscarAutorPorNombre() {
        System.out.print("Ingrese el nombre del autor: ");
        String nombreAutor = leer.next();

        Autor autor = autorServicio.buscarAutorPorNombre(nombreAutor);

        if (autor == null) {
            System.out.println("El autor no existe en la base de datos.");
        }
        return autor;
    }
    
    public Long buscarLibroPorISBN() {
        Long isbn = null;

        while (true) {
            try {
                System.out.print("Ingrese el ISBN: ");
                isbn = leer.nextLong();

                if (isbn <= 0) {
                    System.out.println("El ISBN debe ser un número positivo.");
                } else {
                    break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un ISBN válido (número positivo).");
                leer.nextLine();
            }
        }

        return isbn;
    }

    public boolean isbnRepetido(Long isbn) {
        return libroDAO.buscarLibroPorID(isbn) != null;
    }
    
    public List<Libro> buscarLibroPorTitulo() {
        try {
            System.out.print("Ingrese el título del libro: ");
            String titulo = leer.next();

            List<Libro> libros = libroDAO.buscarLibrosPorTitulo(titulo);

            if (libros.isEmpty()) {
                System.out.println("No se encontraron libros que contengan el título proporcionado.");
            } else {
                System.out.println("Libros encontrados:");
                for (Libro libro : libros) {
                    System.out.println(libro.getTitulo());
                }
            }

            return libros;
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un título válido.");
            return null;
        }
    }

    public List<Libro> buscarLibrosPorAutor() {
        try {
            System.out.print("Ingrese el nombre del autor: ");
            String nombreAutor = leer.next();

            Autor autor = autorServicio.buscarAutorPorNombre(nombreAutor);

            if (autor == null) {
                System.out.println("No se encontró un autor con el nombre proporcionado.");
                return new ArrayList<>();
            }

            List<Libro> libros = libroDAO.buscarLibrosPorAutor(autor);

            if (libros.isEmpty()) {
                System.out.println("No se encontraron libros escritos por el autor.");
            } else {
                System.out.println("Libros escritos por " + nombreAutor + ":");
                for (Libro libro : libros) {
                    System.out.println(libro.getTitulo());
                }
            }

            return libros;
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un nombre de autor válido.");
            return new ArrayList<>();
        }
    }
    
    public List<Libro> buscarLibrosPorEditorial() {
        EditorialServicio editorialServicio = new EditorialServicio();
        try {
            System.out.print("Ingrese el nombre de la editorial: ");
            String nombreEditorial = leer.next();

            List<Editorial> editoriales = editorialServicio.buscarEditorialesPorNombre(nombreEditorial);

            if (editoriales.isEmpty()) {
                System.out.println("No se encontró una editorial con el nombre proporcionado.");
                return new ArrayList<>();
            }

            List<Libro> libros = new ArrayList<>();
            for (Editorial editorial : editoriales) {
                List<Libro> librosEditorial = libroDAO.buscarLibrosPorEditorial(editorial);
                libros.addAll(librosEditorial);
            }

            if (libros.isEmpty()) {
                System.out.println("No se encontraron libros de la(s) editorial(es) " + nombreEditorial + ".");
            } else {
                System.out.println("Libros de la(s) editorial(es) " + nombreEditorial + ":");
                for (Libro libro : libros) {
                    System.out.println(libro.getTitulo());
                }
            }

            return libros;
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un nombre de editorial válido.");
            return new ArrayList<>();
        }
    }
    
    public Libro buscarLibroPorISBN(long isbn) {
        return libroDAO.buscarLibroPorID(isbn);
    }
}
