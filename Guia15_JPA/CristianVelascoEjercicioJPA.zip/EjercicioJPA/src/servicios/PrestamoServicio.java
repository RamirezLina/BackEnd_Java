package servicios;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Cliente;
import libreria.entidades.Libro;
import libreria.entidades.Prestamo;
import persistencia.PrestamoDAO;

public class PrestamoServicio {

    private Scanner leer;
    private final PrestamoDAO prestamoDAO = new PrestamoDAO();
    private final ClienteServicio clienteServicio;
    private final LibroServicio libroServicio;

    public PrestamoServicio() {
        this.leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
        this.clienteServicio = new ClienteServicio();
        this.libroServicio = new LibroServicio();
    }

    public void crearPrestamo() {
        Prestamo prestamo = new Prestamo();

        Date fechaInicio = ingresarFecha("inicio del préstamo");
        prestamo.setFechaPrestamo(fechaInicio);

        Date fechaDevolucion = ingresarFecha("devolución");
        prestamo.setFechaDevolucion(fechaDevolucion);
        
        ClienteServicio clienteServicio = new ClienteServicio();
        Cliente cliente = clienteServicio.crearCliente();
        prestamo.setCliente(cliente);

        Libro libro = libroServicio.crearLibro();

        prestamo.setLibro(libro);
        
        prestamoDAO.persistirEntidad(prestamo);
        
        System.out.println("El préstamo se ha generado exitosamente.");
    }

    private Date ingresarFecha(String tipo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        while (true) {
            System.out.print("Ingrese Fecha de " + tipo + " (dd/MM/yyyy) *La barra('/') también van: ");
            String fechaStr = leer.next();
            try {
                Date fecha = dateFormat.parse(fechaStr);
                if (esFechaValida(fechaStr)) {
                    return fecha;
                } else {
                    System.out.println("La fecha de " + tipo + " no es válida. Ingrese una fecha válida.");
                }
            } catch (ParseException e) {
                System.out.println("Error: Ingrese una fecha válida en formato dd/MM/yyyy.");
            }
        }
    }

    public void mostrarPrestamoPorID() {
        Long idPrestamo = buscarPrestamoPorID();

        if (idPrestamo != null) {
            Prestamo prestamo = prestamoDAO.buscarPrestamoPorID(idPrestamo);

            if (prestamo != null) {
                System.out.println("Información del Préstamo:");
                System.out.println("ID: " + prestamo.getId());
                System.out.println("Fecha de Préstamo: " + prestamo.getFechaPrestamo());
                System.out.println("Fecha de Devolución: " + prestamo.getFechaDevolucion());
                System.out.println("Libro Título: \n" + prestamo.getLibro().getTitulo());
                System.out.println("Libro Autor: " + prestamo.getLibro().getAutor());
                System.out.println("Libro ISBN: " + prestamo.getLibro().getIsbn());
                System.out.println("Cliente Apellido: " + prestamo.getCliente().getApellido());
                System.out.println("Cliente Nombre: " + prestamo.getCliente().getNombre());
                System.out.println("Cliente ID: " + prestamo.getCliente().getId());
            } else {
                System.out.println("No se encontró un préstamo con el ID proporcionado.");
            }
        }
    }

    public Long buscarPrestamoPorID() {
        Long idPrestamo = null;

        try {
            System.out.print("Ingrese el ID del préstamo: ");
            idPrestamo = leer.nextLong();

            if (idPrestamo <= 0) {
                System.out.println("El ID del préstamo debe ser un número positivo.");
                idPrestamo = null;
            } else {
                Prestamo prestamo = prestamoDAO.buscarPrestamoPorID(idPrestamo);
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID de préstamo válido (número positivo).");
            leer.nextLine();
            idPrestamo = null;
        }

        return idPrestamo;
    }
    
    public void mostrarPrestamos() {
        List<Prestamo> prestamos = prestamoDAO.buscarPrestamos();

        if (prestamos.isEmpty()) {
            System.out.println("No hay préstamos registrados en la base de datos.");
        } else {
            System.out.println("Lista de Préstamos:");
            for (Prestamo prestamo : prestamos) {
                System.out.println("ID: " + prestamo.getId());
                System.out.println("Fecha de Préstamo: " + prestamo.getFechaPrestamo());
                System.out.println("Fecha de Devolución: " + prestamo.getFechaDevolucion());
                System.out.println("Libro Título: " + prestamo.getLibro().getTitulo());
                System.out.println("Libro Autor: \n" + prestamo.getLibro().getAutor());
                System.out.println("Libro ISBN: " + prestamo.getLibro().getIsbn());
                System.out.println("Cliente Apellido: " + prestamo.getCliente().getApellido());
                System.out.println("Cliente Nombre: " + prestamo.getCliente().getNombre());
                System.out.println("Cliente ID: " + prestamo.getCliente().getId());
                System.out.println("|----------------------------|");
            }
        }
    }
    
    public void eliminarPrestamoPorID() {
        try {
            System.out.print("Ingrese el ID del préstamo que desea eliminar permanentemente: ");
            Long id = leer.nextLong();

            prestamoDAO.eliminarPermanentePorID(id);

            System.out.println("El préstamo ha sido eliminado permanentemente.");
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
            leer.nextLine();
        }
    }
    
    public void modificarFechaPrestamo() {
        Long idPrestamo = buscarPrestamoPorID();

        if (idPrestamo != null) {
            Prestamo prestamo = prestamoDAO.buscarPrestamoPorID(idPrestamo);

            if (prestamo != null) {
                Date nuevaFechaInicio = ingresarFecha("nuevo inicio del préstamo");
                Date nuevaFechaDevolucion = ingresarFecha("nueva fecha de devolución");

                prestamo.setFechaPrestamo(nuevaFechaInicio);
                prestamo.setFechaDevolucion(nuevaFechaDevolucion);

                prestamoDAO.actualizarEntidad(prestamo);
                System.out.println("El préstamo ha sido modificado exitosamente.");
            } else {
                System.out.println("No se encontró un préstamo con el ID proporcionado.");
            }
        }
    }


    private boolean esFechaValida(String fecha) {
        String[] partes = fecha.split("/");

        if (partes.length != 3) {
            System.out.println("La fecha no tiene el formato correcto (dd/mm/aaaa)");
            return false;
        }

        try {
            int dia = Integer.parseInt(partes[0]);
            int mes = Integer.parseInt(partes[1]);
            int anio = Integer.parseInt(partes[2]);

            if (anio < 1900 || anio > 2100) {
                System.out.println("El año debe estar entre 1900 y 2100.");
                return false;
            }

            if (mes < 1 || mes > 12) {
                System.out.println("El mes debe estar entre 1 y 12.");
                return false;
            }

            int maxDias = 31;

            if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                maxDias = 30;
            } else if (mes == 2) {
                if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
                    maxDias = 29;
                } else {
                    maxDias = 28;
                }
            }

            if (dia < 1 || dia > maxDias) {
                System.out.println("El día debe estar entre 1 y " + maxDias + " para el mes " + mes + ".");
                return false;
            }

            return true;
        } catch (NumberFormatException e) {
            System.out.println("Error: No se pueden convertir a números enteros.");
        }

        return false;
    }
    
}
