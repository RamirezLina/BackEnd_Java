package servicios;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import persistencia.EditorialDAO;
import persistencia.LibroDAO;

public class EditorialServicio {
    
    private final Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    private EditorialDAO editorialDAO = new EditorialDAO();
    private LibroDAO libroDAO = new LibroDAO();
    
    public Editorial crearEditorial() {
        Editorial editorial = new Editorial();

        try {
            System.out.print("Ingrese el nombre de la editorial: ");
            String nombre = leer.next();

            if (nombre.isEmpty()) {
                throw new InputMismatchException("El nombre de la editorial no puede estar vacío.");
            }
            editorial.setNombre(nombre);
            editorial.setAlta(true); 
            
            editorialDAO.persistirEntidad(editorial);

            System.out.println("La editorial se ha creado exitosamente.");
        } catch (InputMismatchException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return editorial;
    }
    
    public void eliminarEditorialPorID() {
        try {
            Long idEditorial = obtenerIDParaEliminar();
            if (idEditorial != null) {
                Editorial editorial = editorialDAO.buscarEditorialPorID(idEditorial);

                if (editorial != null) {

                    if (editorial.getAlta()) {
                        editorial.setAlta(false);
                        editorialDAO.actualizarEntidad(editorial);
                        System.out.println("La editorial ha sido eliminado exitosamente.");
                    } else {
                        editorial.setAlta(true);
                        editorialDAO.actualizarEntidad(editorial);
                        System.out.println("La editorial ha sido restaurada exitosamente.");
                    }
                } else {
                    System.out.println("No se encontró una editorial con el ID proporcionado.");
                }
            } else {
                System.out.println("ID no válido. Ingrese un ID numérico válido.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }

    private Long obtenerIDParaEliminar() {
        System.out.print("Ingrese el ID de la editorial que desea eliminar: ");
        try {
            Long idEditorial = leer.nextLong();
            return idEditorial;
        } catch (InputMismatchException e) {
            return null;
        }
    }
    
    public void mostrarEditoriales() {
        List<Editorial> editoriales = editorialDAO.buscarEditoriales();

        if (editoriales.isEmpty()) {
            System.out.println("No hay editoriales registradas en la base de datos.");
        } else {
            System.out.println("Lista de Editoriales:");
            for (Editorial editorial : editoriales) {
                System.out.println(editorial);
            }
        }
    }
    
    public void eliminarEditorialPermanentePorID() {
        try {
            System.out.print("Ingrese el ID de la editorial que desea eliminar permanentemente: ");
            Long idEditorial = leer.nextLong();

            Editorial editorial = editorialDAO.buscarEditorialPorID(idEditorial);

            if (editorial != null) {
                if (tieneLibrosAsociados(editorial)) {
                    System.out.println("No se puede eliminar esta editorial directamente, ya que tiene libros asociados.");
                    System.out.println("Primero elimine los libros relacionados con esta editorial.");
                } else {
                    editorialDAO.eliminarPermanentePorID(idEditorial);
                    System.out.println("La editorial ha sido eliminado permanentemente.");
                }
            } else {
                System.out.println("No se encontró una editorial con el ID proporcionado.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }
    
    private boolean tieneLibrosAsociados(Editorial editorial) {
        List<Libro> librosDelAutor = libroDAO.buscarLibrosPorEditorial(editorial);

        return !librosDelAutor.isEmpty();
    }
    
    public List<Editorial> buscarEditorialesPorNombre(String nombreEditorial) {
        return editorialDAO.buscarEditorialPorNombreLista(nombreEditorial);
    }
    
    public Editorial buscarEditorialPorNombre(String nombreEditorial) {
        return editorialDAO.buscarEditorialPorNombre(nombreEditorial);
    }
}
