package servicios;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Cliente;
import persistencia.ClienteDAO;

public class ClienteServicio {
    private Scanner leer;
    private final ClienteDAO clienteDAO = new ClienteDAO();
    
    public ClienteServicio() {
        this.leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    }
    
    public Cliente crearCliente() {
        Long documento;
        Cliente clienteExistente;

        do {
            documento = leerLong("documento del cliente");
            clienteExistente = clienteDAO.buscarClientePorDocumento(documento);

            if (clienteExistente != null) {
                System.out.println("Ya existe un cliente con el número de documento proporcionado: " + documento);
                System.out.println("Vuelve a ingresar el documento");
            }
        } while (clienteExistente != null);

        Cliente cliente = new Cliente();
        cliente.setDocumento(documento);
        cliente.setNombre(leerString("nombre del cliente"));
        cliente.setApellido(leerString("apellido del cliente"));
        cliente.setTelefono(leerString("teléfono del cliente"));

        clienteDAO.persistirEntidad(cliente);

        System.out.println("El cliente se ha creado exitosamente.");
        return cliente;
    }

    
    public void eliminarClientePorDocumento() {
        
        try {
            System.out.print("Ingrese el documento del cliente que desea eliminar permanentemente: ");
            Long documento = leer.nextLong();

            Cliente cliente = clienteDAO.buscarClientePorDocumento(documento);
            if (cliente != null) {

                clienteDAO.eliminarPorDocumento(documento);

            } else {
                System.out.println("No se encontró un cliente con el ID proporcionado.");
            }
            
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un ID válido.");
        }
    }
    
    public void consultarClientePorDocumento() {
        Long documento = leerLong("número de documento");

        Cliente cliente = clienteDAO.buscarClientePorDocumento(documento);

        if (cliente != null) {
            mostrarCliente(cliente);
        } else {
            System.out.println("No se encontró un cliente con el número de documento proporcionado: " + documento);
        }
    }

    public void mostrarListaClientes() {
        List<Cliente> clientes = clienteDAO.listarClientes();

        if (!clientes.isEmpty()) {
            System.out.println("Lista de clientes:");
            for (Cliente cliente : clientes) {
                mostrarCliente(cliente);
            }
        } else {
            System.out.println("No hay clientes registrados en la base de datos.");
        }
    }

    private void mostrarCliente(Cliente cliente) {
        System.out.println("ID: " + cliente.getId());
        System.out.println("Documento: " + cliente.getDocumento());
        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Apellido: " + cliente.getApellido());
        System.out.println("Teléfono: " + cliente.getTelefono());
        System.out.println("|----------------------------|");
    }
    
    public void modificarCliente() {
        Long documento = leerLong("documento del cliente");

        Cliente cliente = clienteDAO.buscarClientePorDocumento(documento);

        if (cliente != null) {
            System.out.println("Datos actuales del cliente:");
            mostrarCliente(cliente);

            String nuevoNombre = leerString("Nombre del cliente");
            String nuevoApellido = leerString("Apellido del cliente");
            Long nuevoDocumento = leerLong("Documento del cliente");

            Cliente clienteExistente = clienteDAO.buscarClientePorDocumento(nuevoDocumento);
            if (clienteExistente != null && !clienteExistente.equals(cliente)) {
                System.out.println("Ya existe un cliente con el nuevo número de documento proporcionado: " + nuevoDocumento);
            } else {
                String nuevoTelefono = leerString("Teléfono del cliente");

                cliente.setNombre(nuevoNombre);
                cliente.setApellido(nuevoApellido);
                cliente.setDocumento(nuevoDocumento);
                cliente.setTelefono(nuevoTelefono);

                clienteDAO.actualizarEntidad(cliente);
                System.out.println("El cliente ha sido modificado exitosamente.");
            }
        } else {
            System.out.println("No se encontró un cliente con el documento proporcionado.");
        }
    }
    
    public Cliente buscarClientePorDocumento() {
        Long documento = leerLong("documento del cliente");

        Cliente cliente = clienteDAO.buscarClientePorDocumento(documento);
        return cliente;
    }

    private Long leerLong(String mensaje) {
        while (true) {
            try {
                System.out.print("Ingrese el " + mensaje + ": ");
                Long valor = leer.nextLong();
                if (valor != null) {
                    return valor;
                }
            } catch (InputMismatchException e) {
                leer.nextLine();
                System.out.println("Error: El " + mensaje + " debe ser un número válido.");
            }
            System.out.println("El " + mensaje + " debe ser un número válido.");
        }
    }

    private String leerString(String mensaje) {
        while (true) {
            System.out.print("Ingrese el " + mensaje + ": ");
            String valor = leer.next().trim();
            if (!valor.isEmpty()) {
                return valor;
            }
            System.out.println("El " + mensaje + " no puede estar vacío.");
        }
    }
    
}
