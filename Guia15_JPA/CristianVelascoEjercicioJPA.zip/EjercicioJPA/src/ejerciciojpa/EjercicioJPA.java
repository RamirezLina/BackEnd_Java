package ejerciciojpa;

import java.util.Scanner;
import servicios.AutorServicio;
import servicios.ClienteServicio;
import servicios.EditorialServicio;
import servicios.LibroServicio;
import servicios.PrestamoServicio;

public class EjercicioJPA {

    public static void main(String[] args) {
        
        Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
        LibroServicio libroServicio = new LibroServicio();
        AutorServicio autorServicio = new AutorServicio();
        EditorialServicio editorialServicio = new EditorialServicio();
        ClienteServicio clienteServicio = new ClienteServicio();
        PrestamoServicio prestamoServicio = new PrestamoServicio();
        
        System.out.println("|----------------------------|");
        while (true) {
            System.out.println("Menú de la librería:");
            System.out.println("1) Crear Autor");
            System.out.println("2) Crear Editorial");
            System.out.println("3) Crear Libro");
            System.out.println("4) Eliminar/Dar de alta Autor");
            System.out.println("5) Eliminar/Dar de alta Editorial");
            System.out.println("6) Eliminar/Dar de alta Libro");
            System.out.println("7) Eliminar permanente Autor");
            System.out.println("8) Eliminar permanente Editorial");
            System.out.println("9) Eliminar permanente Libro");
            System.out.println("10) Mostrar Autores");
            System.out.println("11) Mostrar Editoriales");
            System.out.println("12) Mostrar Libros");
            System.out.println("13) Búsqueda de un Autor por nombre");
            System.out.println("14) Búsqueda de un libro por ISBN");
            System.out.println("15) Búsqueda de un libros por Título");
            System.out.println("16) Búsqueda de libros por nombre de Autor");
            System.out.println("17) Búsqueda de libros por nombre de Editorial");
            System.out.println("18) Crear Cliente");
            System.out.println("19) Busqueda de Cliente por documento");
            System.out.println("20) Mostrar Clientes");
            System.out.println("21) Eliminar Cliente por documento");
            System.out.println("22) Modificar Cliente");
            System.out.println("23) Crear Prestamo");
            System.out.println("24) Busqueda de Prestamo por ID");
            System.out.println("25) Mostrar Prestamos");
            System.out.println("26) Eliminar Prestamo");
            System.out.println("27) Modificar fecha de Prestamo");
            System.out.println("0) Salir");

            System.out.print("Ingrese la opción: ");

            try {
                
                int opcion = leer.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("|----------------------------|");
                        autorServicio.crearAutor();
                        System.out.println("|----------------------------|");
                        break;
                    case 2:
                        System.out.println("|----------------------------|");
                        editorialServicio.crearEditorial();
                        System.out.println("|----------------------------|");
                        break;
                    case 3:
                        System.out.println("|----------------------------|");
                        libroServicio.crearLibro();
                        System.out.println("|----------------------------|");
                        break;
                    case 4:
                        System.out.println("|----------------------------|");
                        autorServicio.eliminarAutorPorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 5:
                        System.out.println("|----------------------------|");
                        editorialServicio.eliminarEditorialPorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 6:
                        System.out.println("|----------------------------|");
                        libroServicio.eliminarLibroPorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 7:
                        System.out.println("|----------------------------|");
                        autorServicio.eliminarAutorPermanentePorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 8:
                        System.out.println("|----------------------------|");
                        editorialServicio.eliminarEditorialPermanentePorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 9:
                        System.out.println("|----------------------------|");
                        libroServicio.eliminarLibroPermanentePorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 10:
                        System.out.println("|----------------------------|");
                        autorServicio.mostrarAutores();
                        System.out.println("|----------------------------|");
                        break;
                    case 11:
                        System.out.println("|----------------------------|");
                        editorialServicio.mostrarEditoriales();
                        System.out.println("|----------------------------|");
                        break;
                    case 12:
                        System.out.println("|----------------------------|");
                        libroServicio.mostrarLibros();
                        System.out.println("|----------------------------|");
                        break;
                    case 13:
                        System.out.println("|----------------------------|");
                        libroServicio.buscarAutorPorNombre();
                        System.out.println("|----------------------------|");
                        break;
                    case 14:
                        System.out.println("|----------------------------|");
                        libroServicio.mostrarLibroPorID(libroServicio.buscarLibroPorISBN());
                        System.out.println("|----------------------------|");
                        break;
                    case 15:
                        System.out.println("|----------------------------|");
                        libroServicio.buscarLibroPorTitulo();
                        System.out.println("|----------------------------|");
                        break;
                    case 16:
                        System.out.println("|----------------------------|");
                        libroServicio.buscarLibrosPorAutor();
                        System.out.println("|----------------------------|");
                        break;     
                    case 17:
                        System.out.println("|----------------------------|");
                        libroServicio.buscarLibrosPorEditorial();
                        System.out.println("|----------------------------|");
                        break;
                    case 18:
                        System.out.println("|----------------------------|");
                        clienteServicio.crearCliente();
                        System.out.println("|----------------------------|");
                        break;
                    case 19:
                        System.out.println("|----------------------------|");
                        clienteServicio.consultarClientePorDocumento();
                        break;
                    case 20:
                        System.out.println("|----------------------------|");
                        clienteServicio.mostrarListaClientes();
                        break;
                    case 21:
                        System.out.println("|----------------------------|");
                        clienteServicio.eliminarClientePorDocumento();
                        System.out.println("|----------------------------|");
                        break;
                    case 22:
                        System.out.println("|----------------------------|");
                        clienteServicio.modificarCliente();
                        System.out.println("|----------------------------|");
                        break;
                    case 23:
                        System.out.println("|----------------------------|");
                        prestamoServicio.crearPrestamo();
                        System.out.println("|----------------------------|");
                        break;
                    case 24:
                        System.out.println("|----------------------------|");
                        prestamoServicio.mostrarPrestamoPorID();
                        System.out.println("|----------------------------|");
                        break;
                    case 25:
                        System.out.println("|----------------------------|");
                        prestamoServicio.mostrarPrestamos();
                        break;
                    case 26:
                        System.out.println("|----------------------------|");
                        prestamoServicio.eliminarPrestamoPorID(); 
                        System.out.println("|----------------------------|");
                        break;
                    case 27:
                        System.out.println("|----------------------------|");
                        prestamoServicio.modificarFechaPrestamo();
                        System.out.println("|----------------------------|");
                        break;
                    case 0:
                        System.out.println("Saliendo del programa.");
                        System.exit(0);
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
    
}